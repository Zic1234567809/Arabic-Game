using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class Score : MonoBehaviour
{
    private TextMeshProUGUI scoreText;
    private TextMeshProUGUI timerText;
    public static float levelScore;
    private float timeInLevel;
    private float score;

    void Start()
    {
        scoreText = GameObject.Find("ScoreText").GetComponent<TextMeshProUGUI>();
        timerText = GameObject.Find("TimerText").GetComponent<TextMeshProUGUI>();
    }

    void Update()
    {
        timeInLevel += Time.deltaTime;
        levelScore = Mathf.Round(90f - timeInLevel);
        if(levelScore < 0)
        {
            score = 0f;
            timeInLevel = 0f;
            SceneManager.LoadScene(0);
        }
        scoreText.text = score.ToString();
        Debug.Log(1);
        timerText.text = levelScore.ToString();
    }

    public void NextLevel()
    {
        score += levelScore;
        timeInLevel = 0f;
    }
}
